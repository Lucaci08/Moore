﻿using System;

namespace ChangeTemperature
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Temperature Changer");
            Console.WriteLine("Press F for farenheit to celsius");
            Console.WriteLine("Press C for celsius to farenheit");
            string MeniuChoice = Console.ReadLine().ToUpper();
            switch (MeniuChoice)

            {
                case "F":
                    ConvertToFarenheit();
                    break;
                case "C":
                    ConvertToCelsius();
                    break;
                default:
                    break;
            }
        }
        static void ConvertToFarenheit()
        {
            Console.WriteLine("Insert temperature in celsius");
            float val = Convert.ToInt32(Console.ReadLine());
            val = (val * 9) / 5 + 32;
            Console.WriteLine("value in farenheit is:" + val);

        }

        static void ConvertToCelsius()
        {
            Console.WriteLine("Insert temperature in farenheit");
            float val = Convert.ToInt32(Console.ReadLine());
            val = (val - 32) * 5 / 9;
            Console.WriteLine("value in celsius is:" + val);

        }

    }
}